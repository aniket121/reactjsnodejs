
from django.conf.urls import url
from django.contrib import admin
from django.conf.urls import url, include
from .views import *
urlpatterns = [
    url(r'^register-user/', registerUser.as_view(), name='registerUser'),
    url(r'^login-user/', loginUser.as_view(), name='loginUser'),
]
